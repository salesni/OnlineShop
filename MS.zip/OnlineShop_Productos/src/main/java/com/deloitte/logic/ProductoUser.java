package com.deloitte.logic;

/**
 * 
 * This class is for retrieving the information of the product form the DataBase, but filter as this information
 * is set to be displayed in the front-end. 
 * 
 * @param descripcion, precio, categoria from the DataBase
 * 
 * @version 1.0.0 12/11/2020
 * @author Salvador Fuentes
 * 
 */

public class ProductoUser {


	private String descripcion;
	private double precio;
	private String categoria;
	
	public ProductoUser() {
		
	}

	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	
	

}
