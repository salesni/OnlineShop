package com.deloitte.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.exception.ResourceNotFoundException;
import com.deloitte.logic.ProductoUser;
import com.deloitte.model.Producto;
import com.deloitte.model.repository.ProductoRepository;

/**
 * It is a class that works as a controller for the microservice of the user (client and manager/employee) service and interface (HTML). 
 * The controller works with the specific URL based on the target product.  
 *  
 * @version 1.0.0, 13/11/2020
 * @author Salvador Fuentes
 * @author Eduardo Labastida
 * @author Mirian Hipolito
 */

@RestController
@CrossOrigin
@RequestMapping("api/v1")
public class ProductosController {

	@Autowired
	private ProductoRepository ProductoRespository;
	
	/**
	 * This method returns all the information inside the table Productos. 
	 * 
	 * 
	 * @return A JSON with all the information.
	 * 
	 */
	
	@GetMapping("/Productos")
	public List < Producto > getAllProductos() {
        return ProductoRespository.findAll();
    }
	
	/**
	 * This method returns the information of a product based on the ID and it is used by the manager. 
	 * 
	 * @param idProducto
	 * @return An object call Producto.
	 * @throws ResourceNotFoundException
	 */
	@GetMapping("/Productos/{idProducto}")
	public ResponseEntity<Producto> getProductoById(@PathVariable(value = "idProducto") Integer idProducto) throws ResourceNotFoundException {
		Producto Producto = ProductoRespository.findById(idProducto)
				.orElseThrow(() -> new ResourceNotFoundException("Producto "+ idProducto + " does not exists!!!!"));
		return ResponseEntity.ok().body(Producto);
	}
	
	/**
	 * This method returns the product that a user is looking for by searching the name. This method is for the user interface.  
	 * 
	 * @param descripcion
	 * @return An object call userProducto.
	 * @throws ResourceNotFoundException
	 */
	@GetMapping("/ProductosUser/{descripcion}")
	public ResponseEntity<ProductoUser> getByDescripcion(@PathVariable(value = "descripcion") String descripcion) throws ResourceNotFoundException {
		Producto Producto = ProductoRespository.getByDescripcion(descripcion);
		if(Producto == null) {
			throw new ResourceNotFoundException("Producto "+ descripcion + " does not exists!!!!");
		}
		ProductoUser userProducto = new ProductoUser();
		userProducto.setDescripcion(Producto.getDescripccion());
		userProducto.setCategoria(Producto.getCategoria().getDescripcion());
		userProducto.setPrecio(Producto.getPrecio());

		return ResponseEntity.ok().body(userProducto);
	}
	
	/**
	 * This method saves a new product inside the database, it is meant to be inside the managers interface. 
	 * 
	 * @param JSON file with the information needed (descripcion, id_categorias, precio, existencia, image_url).
	 * @return An object call Producto. 
	 * 
	 */
	@PostMapping("/Productos")
    public Producto createProducto(@Valid @RequestBody Producto Producto) {
        return ProductoRespository.save(Producto);
    }

	/**
	 * This method update a product inside the database, it is meant to be inside the managers interface. 
	 * 
	 * @param JSON file with the information needed (id_productos, descripcion, id_categorias, precio, existencia, image_url).
	 * @return An object call updatedProducto. 
	 * @throws ResourceNotFoundException
	 */
	@PutMapping("/Productos/{idUsers}")
    public ResponseEntity < Producto > updateProducto(@PathVariable(value = "idUsers") Integer ProductoId,
        @Valid @RequestBody Producto ProductoDetails) throws ResourceNotFoundException {
        Producto Producto = ProductoRespository.findById(ProductoId)
            .orElseThrow(() -> new ResourceNotFoundException("Producto not found for this id :: " + ProductoId));

        Producto.setDescripcion(ProductoDetails.getDescripccion());
        Producto.setPrecio(ProductoDetails.getPrecio());
        Producto.setCategoria(ProductoDetails.getCategoria());
        Producto.setExistencia(ProductoDetails.getExistencia());
        Producto.setImage_url(ProductoDetails.getImage_url());
        
        final Producto updatedProducto = ProductoRespository.save(Producto);
        return ResponseEntity.ok(updatedProducto);
    }
	
	/**
	 * This method deletes a product inside the database, it is meant to be inside the managers interface. 
	 * 
	 * @param JSON file with the information needed (id_productos).
	 * @return An object call Producto. 
	 * @throws ResourceNotFoundException
	 */
	@DeleteMapping("/Productos/{idProductos}")
    public Map < String, Boolean > deleteProducto(@PathVariable(value = "idProductos") Integer ProductoId)
    throws ResourceNotFoundException {
        Producto Producto = ProductoRespository.findById(ProductoId)
            .orElseThrow(() -> new ResourceNotFoundException("Producto not found for this id :: " + ProductoId));

        ProductoRespository.delete(Producto);
        Map < String, Boolean > response = new HashMap < > ();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
	
	
}